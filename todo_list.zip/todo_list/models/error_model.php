<?php

class Error_Model extends Model
{
	public function __construct()
	{parent::__construct();}
	
	
		}