<?php

// Always provide a TRAILING SLASH (/) AFTER A PATH

define('URL', 'http://localhost/');
define('template', URL.'bootstrap/');
define('js', URL.'js/');


define('LIBS', 'libs/');?>